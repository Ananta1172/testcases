 package com.exam.Examrepositary;



import org.springframework.data.repository.CrudRepository;

import com.exam.beans.PaymentMethod;

public interface Examrepositary extends CrudRepository<PaymentMethod,String>
{
        
}
   