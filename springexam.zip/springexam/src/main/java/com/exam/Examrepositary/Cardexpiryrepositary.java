package com.exam.Examrepositary;

import org.springframework.data.repository.CrudRepository;

import com.exam.beans.CardExpiry;

public interface Cardexpiryrepositary extends CrudRepository<CardExpiry,String>
{

}
