package com.exam.Examrepositary;

import org.springframework.data.repository.CrudRepository;

import com.exam.beans.BilingDetails;

public interface BillingRepositary extends CrudRepository<BilingDetails ,String>
{
       
}
