package com.exam.beans;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.beans.factory.annotation.Autowired;

import com.exam.beans.CardExpiry;
@Entity
public class Card 
{
	
	//private CardExpiry cardExpiry;
	private String holderName;
	private String cardType;
	@Id
	private String cardBin;
	private String lastDigits;
	
/*	public CardExpiry getCardExpiry() {
	//	return cardExpiry;
	}
	public void setCardExpiry(CardExpiry cardExpiry) {
		this.cardExpiry = cardExpiry;
	}*/
	public String getHolderName() {
		return holderName;
	}
	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public String getCardBin() {
		return cardBin;
	}
	public void setCardBin(String cardBin) {
		this.cardBin = cardBin;
	}
	public String getLastDigits() {
		return lastDigits;
	}
	public void setLastDigits(String lastDigits) {
		this.lastDigits = lastDigits;
	}
	
	@Override
	public String toString() {
		return "holderName=" + holderName + ", cardType=" + cardType + ", cardBin="
				+ cardBin + ", lastDigits=" + lastDigits + "]";
	}
	

}
