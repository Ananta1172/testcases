package com.exam.controller;
/*
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.exam.Examrepositary.Cardexpiryrepositary;
import com.exam.beans.CardExpiry;
@RestController
@RequestMapping("/cardexpiry")
public class CardExpiryController 
{
	   @Autowired
       private Cardexpiryrepositary card;
       
       @GetMapping("/readAll")
       public Iterable<CardExpiry> readAll()
       {
    	  return  card.findAll();
       }
       
       
}
*/