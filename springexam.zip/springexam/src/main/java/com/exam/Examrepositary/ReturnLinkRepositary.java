package com.exam.Examrepositary;

import org.springframework.data.repository.CrudRepository;

import com.exam.beans.Returnlink;

public interface ReturnLinkRepositary extends CrudRepository<Returnlink ,String>
{
	

}
