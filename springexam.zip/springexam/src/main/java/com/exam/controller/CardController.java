package com.exam.controller;
/*
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.exam.Examrepositary.CardRepositary;
import com.exam.beans.Card;

@RestController
@RequestMapping("/card")
public class CardController 
{
	@Autowired
	private CardRepositary cd;
	
	@GetMapping("/readAll")
	public Iterable<Card> readAll()
	{
		return cd.findAll();
	}
	
}
*/